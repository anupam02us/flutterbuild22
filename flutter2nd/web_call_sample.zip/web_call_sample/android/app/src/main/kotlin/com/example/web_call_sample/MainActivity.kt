package com.example.web_call_sample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
